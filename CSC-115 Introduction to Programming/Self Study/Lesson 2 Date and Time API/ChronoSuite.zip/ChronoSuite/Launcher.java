// Creation Date: August 21, 2026. at 12:02 AM
// Last Modified: November 27, 2026. at  9:03 PM

import CLI.Menu;

public class Launcher {
    // =========================== CLASS VARIABLES =========================== \\

    // [OBJECTS]
    private static Menu menu = new Menu();

    // =========================== MAIN =========================== \\
    public static void main(String[] args) {
        menu.Main();
    }

    // =========================== METHODS =========================== \\
}

// [INITIAL IDEA 1.2:]
// Add an exception if a user decides to exit the application because our application is running in an infinite while lopp.
// [INITIAL IDEA 1.3:]
// Add AES Encryption, Hashing Password
// I am currently using a raw password String and users are able to see it throught the object file.
// This whole cryptography thing will be a whole entire different thing so I am planning to learn it after I finish this project.
// Add AES Encryption, Hashing Password
// I am currently using a raw password String and users are able to see it throught the object file.
// This whole cryptography thing will be a whole entire different thing so I am planning to learn it after I finish this project.
